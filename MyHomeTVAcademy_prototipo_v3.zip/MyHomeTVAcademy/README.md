# My Home TV Academy

Primera versión navegable del proyecto Android.

Incluye:
- Inicio
- Inicio de sesión (interfaz)
- Curso completo
- 5 módulos
- Lista de clases
- Progreso básico
- Logo definitivo

Esta versión es un prototipo local: todavía no incluye servidor, pagos,
autenticación real, almacenamiento de videos ni certificados dinámicos.

Siguiente fase:
1. Backend y base de datos.
2. Usuarios y compras.
3. Almacenamiento/streaming privado de videos.
4. Panel administrativo.
5. Certificado PDF automático.
6. Compilación y firma de la APK de producción.

## Milestone 2
Se añadió el flujo visual de registro/inicio de sesión:
- Cambio entre iniciar sesión y crear cuenta.
- Nombre completo en registro.
- Correo y contraseña.
- Recuperación de contraseña (placeholder).
- Mensajes de estado.
La persistencia real y autenticación segura se conectarán en la siguiente fase con backend.


## Milestone 3
Se añadió una persistencia local de demostración para cuentas:
- Registro guarda nombre, correo y contraseña en el almacenamiento local del prototipo.
- Inicio de sesión valida esos datos.
- El nombre del alumno aparece en Inicio.
- Se puede cerrar sesión.

**Importante:** esto NO es todavía el backend de producción. Para producción sustituiremos este repositorio local por autenticación segura y base de datos en la nube. Nunca debemos guardar contraseñas en texto plano en la versión final.
