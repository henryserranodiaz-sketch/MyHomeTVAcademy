
package com.myhome.tvacademy

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Red = Color(0xFFE50914)
private val Dark = Color(0xFF11151A)
private val TextDark = Color(0xFF182333)

private data class StudentAccount(
    val name: String,
    val email: String
)

private class LocalAccountRepository(context: Context) {
    private val prefs = context.getSharedPreferences("academy_account", Context.MODE_PRIVATE)

    fun register(name: String, email: String, password: String): Boolean {
        if (name.isBlank() || email.isBlank() || password.isBlank()) return false
        prefs.edit()
            .putString("name", name.trim())
            .putString("email", email.trim())
            .putString("password", password)
            .putBoolean("registered", true)
            .apply()
        return true
    }

    fun login(email: String, password: String): StudentAccount? {
        val savedEmail = prefs.getString("email", null)
        val savedPassword = prefs.getString("password", null)
        val savedName = prefs.getString("name", null)
        return if (savedEmail != null && savedPassword == password &&
            savedEmail.equals(email.trim(), ignoreCase = true)) {
            StudentAccount(savedName.orEmpty(), savedEmail)
        } else null
    }

    fun account(): StudentAccount? {
        if (!prefs.getBoolean("registered", false)) return null
        return StudentAccount(
            prefs.getString("name", "").orEmpty(),
            prefs.getString("email", "").orEmpty()
        )
    }
}

data class Lesson(val title: String, val duration: String, var completed: Boolean = false)
data class Module(val title: String, val description: String, val lessons: List<Lesson>)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { AcademyApp() }
    }
}


@Composable
fun AcademyApp() {
    val context = androidx.compose.ui.platform.LocalContext.current
    val accountRepo = remember { LocalAccountRepository(context) }
    var screen by remember { mutableStateOf(if (accountRepo.account() != null) "home" else "home") }
    var selectedModule by remember { mutableStateOf(0) }
    var loggedInAccount by remember { mutableStateOf(accountRepo.account()) }

    val modules = remember {
        mutableStateListOf(
            Module("Electrónica Básica y Multímetro",
                "Aprende desde cero: mediciones, componentes y uso correcto del multímetro.",
                listOf(
                    Lesson("Bienvenida al módulo", "2:15", true),
                    Lesson("¿Qué es el voltaje?", "4:32"),
                    Lesson("Corriente eléctrica", "4:10"),
                    Lesson("Resistencia", "4:28"),
                    Lesson("Componentes electrónicos", "5:02"),
                    Lesson("Cómo utilizar el multímetro", "6:15"),
                    Lesson("Prueba de diodos", "4:55"),
                    Lesson("Mediciones prácticas", "6:20")
                )),
            Module("Fuente de Alimentación",
                "Etapas, PWM, MOSFET, PFC, standby y diagnóstico.",
                listOf(
                    Lesson("¿Qué hace una fuente de TV?", "4:12"),
                    Lesson("Entrada de AC", "3:48"),
                    Lesson("El fusible", "2:55"),
                    Lesson("Puente rectificador", "4:36"),
                    Lesson("Capacitor principal", "4:10"),
                    Lesson("¿Qué es el PFC?", "4:50"),
                    Lesson("El MOSFET", "3:40"),
                    Lesson("El PWM", "4:45")
                )),
            Module("Mainboard",
                "Alimentaciones, reguladores, memorias, procesador y diagnóstico.",
                listOf(
                    Lesson("Alimentaciones de la Main", "4:20"),
                    Lesson("Reguladores y LDO", "4:40"),
                    Lesson("DC-DC", "4:15"),
                    Lesson("Memoria SPI", "4:50"),
                    Lesson("eMMC", "4:35"),
                    Lesson("Procesador y señales", "4:55"),
                    Lesson("Firmware", "4:10"),
                    Lesson("Diagnóstico de Mainboard", "5:00")
                )),
            Module("T-Con, Panel y Voltajes",
                "VGH, VGL, AVDD, VCOM, flex, COF y diagnóstico de panel.",
                listOf(
                    Lesson("¿Qué hace la T-Con?", "4:10"),
                    Lesson("VGH y VGL", "4:55"),
                    Lesson("AVDD y VCOM", "4:35"),
                    Lesson("Flex y conectores", "3:50"),
                    Lesson("COF y drivers", "4:45"),
                    Lesson("Media pantalla", "4:20"),
                    Lesson("Líneas e imagen defectuosa", "4:40"),
                    Lesson("Diagnóstico de panel", "5:00")
                )),
            Module("Diagnóstico y Reparación Real",
                "Casos reales paso a paso, desde el síntoma hasta la reparación.",
                listOf(
                    Lesson("Televisor que no enciende", "4:50"),
                    Lesson("Enciende y no hay imagen", "4:45"),
                    Lesson("Parpadeo de standby", "4:30"),
                    Lesson("Pantalla oscura", "4:55"),
                    Lesson("Media pantalla", "4:20"),
                    Lesson("Fuente en protección", "4:40"),
                    Lesson("Falla de Mainboard", "4:50"),
                    Lesson("Caso completo de reparación", "5:00")
                ))
        )
    }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Red,
            background = Color(0xFFF7F8FA),
            surface = Color.White,
            onBackground = TextDark,
            onSurface = TextDark
        )
    ) {
        when (screen) {
            "home" -> HomeScreen(
                account = loggedInAccount,
                onCourses = { screen = "courses" },
                onLogin = { screen = "login" },
                onLogout = {
                    loggedInAccount = null
                    screen = "login"
                }
            )
            "courses" -> CourseScreen(
                modules = modules,
                onBack = { screen = "home" },
                onModule = { selectedModule = it; screen = "module" }
            )
            "module" -> ModuleScreen(
                module = modules[selectedModule],
                onBack = { screen = "courses" }
            )
            "login" -> LoginScreen(
                repository = accountRepo,
                onBack = { screen = "home" },
                onAuthenticated = {
                    loggedInAccount = it
                    screen = "home"
                }
            )
        }
    }
}

@Composable
fun Header(onBack: (() -> Unit)? = null, title: String = "") {
    Row(
        Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        if (onBack != null) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
        }
        Text(title, fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.weight(1f))
        Icon(Icons.Default.Notifications, null)
        Spacer(Modifier.width(12.dp))
        Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(30.dp))
    }
}

@Composable
fun HomeScreen(account: StudentAccount?, onCourses: () -> Unit, onLogin: () -> Unit, onLogout: () -> Unit) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(Color(0xFFF7F8FA)),
        contentPadding = PaddingValues(18.dp)
    ) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Menu, null, modifier = Modifier.size(30.dp))
                Spacer(Modifier.weight(1f))
                Text("My Home TV Academy", fontWeight = FontWeight.Bold)
                Spacer(Modifier.weight(1f))
                Icon(Icons.Default.AccountCircle, null, modifier = Modifier.size(30.dp).clickable { if (account == null) onLogin() else onLogout() })
            }
            Spacer(Modifier.height(12.dp))
            Image(
                painterResource(com.myhome.tvacademy.R.drawable.myhome_tv_academy_logo),
                null, modifier = Modifier.fillMaxWidth().height(220.dp),
                contentScale = ContentScale.Fit
            )
            Text("APRENDE  •  REPARA  •  AVANZA",
                modifier = Modifier.fillMaxWidth(), textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                fontWeight = FontWeight.Bold, color = Red, letterSpacing = 2.sp)
            Spacer(Modifier.height(18.dp))
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(20.dp)) {
                    Text(if (account == null) "¡Hola, bienvenido!" else "¡Hola, ${account.name}!", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                    Text("Tu plataforma de capacitación en reparación de televisores.",
                        fontSize = 16.sp, color = Color(0xFF536274))
                }
            }
            Spacer(Modifier.height(14.dp))
        }

        item {
            HomeCard(Icons.Default.School, "Mis Cursos", "Continúa tu aprendizaje") { onCourses() }
            HomeCard(Icons.Default.MenuBook, "Cursos Disponibles", "Explora nuevos temas") { onCourses() }
            HomeCard(Icons.Default.BarChart, "Mi Progreso", "Tu avance en el curso") { onCourses() }
            HomeCard(Icons.Default.Description, "Recursos", "Diagramas, manuales y más") {}
            HomeCard(Icons.Default.ShoppingCart, "Comprar Curso", "Accede a más contenido") { onCourses() }
            HomeCard(Icons.Default.SupportAgent, "Soporte", "Estamos para ayudarte") {}
        }

        item {
            Spacer(Modifier.height(8.dp))
            Card(shape = RoundedCornerShape(18.dp), colors = CardDefaults.cardColors(containerColor = Color(0xFFF0F2F5))) {
                Row(Modifier.padding(20.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.width(5.dp).height(80.dp).background(Red, RoundedCornerShape(4.dp)))
                    Spacer(Modifier.width(16.dp))
                    Column {
                        Text("“La práctica hoy,\nes el éxito mañana”", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Text("Genry Serrano", fontSize = 18.sp, color = Red)
                    }
                }
            }
        }
    }
}

@Composable
fun HomeCard(icon: androidx.compose.ui.graphics.vector.ImageVector, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        Modifier.fillMaxWidth().padding(vertical = 6.dp).clickable { onClick() },
        shape = RoundedCornerShape(16.dp)
    ) {
        Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = Red, modifier = Modifier.size(42.dp))
            Spacer(Modifier.width(18.dp))
            Column {
                Text(title, fontSize = 19.sp, fontWeight = FontWeight.Bold)
                Text(subtitle, color = Color(0xFF667383))
            }
            Spacer(Modifier.weight(1f))
            Icon(Icons.Default.ChevronRight, null)
        }
    }
}



@Composable
fun LoginScreen(
    repository: LocalAccountRepository,
    onBack: () -> Unit,
    onAuthenticated: (StudentAccount) -> Unit
) {
    var mode by remember { mutableStateOf("login") }
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    Column(Modifier.fillMaxSize().background(Color(0xFFF7F8FA)).padding(24.dp)) {
        Header(onBack, if (mode == "login") "Iniciar sesión" else "Crear cuenta")
        Spacer(Modifier.height(10.dp))
        Image(
            painterResource(R.drawable.myhome_tv_academy_logo), null,
            Modifier.fillMaxWidth().height(170.dp), contentScale = ContentScale.Fit
        )
        Spacer(Modifier.height(10.dp))

        if (mode == "register") {
            OutlinedTextField(
                value = name, onValueChange = { name = it },
                label = { Text("Nombre completo") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(10.dp))
        }

        OutlinedTextField(
            value = email, onValueChange = { email = it },
            label = { Text("Correo electrónico") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(10.dp))

        OutlinedTextField(
            value = password, onValueChange = { password = it },
            label = { Text("Contraseña") },
            modifier = Modifier.fillMaxWidth()
        )
        Spacer(Modifier.height(16.dp))

        Button(
            onClick = {
                if (mode == "register") {
                    if (repository.register(name, email, password)) {
                        val account = repository.account()
                        if (account != null) {
                            onAuthenticated(account)
                        }
                    } else {
                        message = "Completa nombre, correo y contraseña."
                    }
                } else {
                    val account = repository.login(email, password)
                    if (account != null) {
                        onAuthenticated(account)
                    } else {
                        message = "Correo o contraseña incorrectos."
                    }
                }
            },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Red)
        ) {
            Text(if (mode == "login") "Iniciar sesión" else "Crear cuenta", fontSize = 18.sp)
        }

        Spacer(Modifier.height(12.dp))

        TextButton(
            onClick = {
                mode = if (mode == "login") "register" else "login"
                message = ""
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                if (mode == "login") "¿No tienes cuenta? Crear cuenta"
                else "¿Ya tienes cuenta? Iniciar sesión",
                color = Red
            )
        }

        if (mode == "login") {
            TextButton(
                onClick = { message = "La recuperación de contraseña se conectará al correo del alumno en el backend." },
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("¿Olvidaste tu contraseña?", color = Color(0xFF5C6878))
            }
        }

        if (message.isNotBlank()) {
            Card(
                Modifier.fillMaxWidth().padding(top = 8.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF1F1))
            ) {
                Text(message, Modifier.padding(14.dp), color = TextDark)
            }
        }
    }
}

@Composable
fun CourseScreen(modules: List<Module>, onBack: () -> Unit, onModule: (Int) -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF7F8FA))) {
        item {
            Header(onBack, "Mi Curso")
            Image(
                painterResource(R.drawable.myhome_tv_academy_logo), null,
                Modifier.fillMaxWidth().height(190.dp), contentScale = ContentScale.Fit
            )
            Text("DIAGNÓSTICO Y REPARACIÓN DE TELEVISORES",
                Modifier.padding(horizontal = 18.dp), fontSize = 22.sp, fontWeight = FontWeight.Bold)
            Text("De cero a nivel profesional",
                Modifier.padding(horizontal = 18.dp, vertical = 4.dp), color = Red, fontWeight = FontWeight.Bold)
            Spacer(Modifier.height(12.dp))
        }
        items(modules.indices.toList()) { i ->
            val m = modules[i]
            val done = m.lessons.count { it.completed }
            ModuleCard(i + 1, m, done, onClick = { onModule(i) })
        }
    }
}

@Composable
fun ModuleCard(number: Int, module: Module, completed: Int, onClick: () -> Unit) {
    val pct = completed.toFloat() / module.lessons.size
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp).clickable { onClick() },
        shape = RoundedCornerShape(18.dp)) {
        Column(Modifier.padding(18.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(42.dp).background(Red, RoundedCornerShape(50.dp)), contentAlignment = Alignment.Center) {
                    Text("$number", color = Color.White, fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(14.dp))
                Column(Modifier.weight(1f)) {
                    Text(module.title, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                    Text("${module.lessons.size} clases", color = Color(0xFF697586))
                }
                Icon(Icons.Default.ChevronRight, null)
            }
            Spacer(Modifier.height(10.dp))
            LinearProgressIndicator(progress = { pct }, modifier = Modifier.fillMaxWidth(), color = Red)
            Text("${(pct * 100).toInt()}%  •  $completed de ${module.lessons.size} clases",
                color = Color(0xFF697586), modifier = Modifier.padding(top = 6.dp))
        }
    }
}

@Composable
fun ModuleScreen(module: Module, onBack: () -> Unit) {
    LazyColumn(Modifier.fillMaxSize().background(Color(0xFFF7F8FA))) {
        item {
            Header(onBack, "Módulo")
            Card(Modifier.padding(16.dp), shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text(module.title, fontSize = 24.sp, fontWeight = FontWeight.Bold)
                    Text(module.description, color = Color(0xFF5C6878), modifier = Modifier.padding(top = 6.dp))
                    Spacer(Modifier.height(12.dp))
                    Text("Lista de clases", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
        items(module.lessons) { lesson ->
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp),
                shape = RoundedCornerShape(14.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (lesson.completed) Icons.Default.CheckCircle else Icons.Default.PlayCircle,
                        null, tint = if (lesson.completed) Color(0xFF18A957) else Red,
                        modifier = Modifier.size(34.dp))
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(lesson.title, fontWeight = FontWeight.Bold, fontSize = 16.sp)
                        Text(lesson.duration, color = Color(0xFF697586))
                    }
                    Text(if (lesson.completed) "Completada" else "Ver clase",
                        color = if (lesson.completed) Color(0xFF18A957) else Red, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}
